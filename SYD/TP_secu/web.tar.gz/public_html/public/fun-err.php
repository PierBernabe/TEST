<html>
  <head>
    <link href="styles/main.css" rel="stylesheet" type="text/css"/>
  </head>
  <body>
    <center>
      <h1 class="err-msg">Invalid function</h1>
    </center>
    <?php include("menu.php"); ?>
  </body>
</html>
