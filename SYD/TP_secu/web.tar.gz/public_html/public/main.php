<html>
  <head>
    <link href="styles/main.css" rel="stylesheet" type="text/css"/>
  </head>
  <body>
    <?php include("menu.php"); ?>
  </body>
</html>
