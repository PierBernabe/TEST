<center>
  <h1>Hello <i><?php print($_SESSION["login"]); ?></i></h1>
  <h2>Menu</h2>
  <a href='proxy.php?F=public/list.php'>List of books</a><br/>
  <a href='proxy.php?F=public/forum.php'>Forum</a><br/>
  <a href='proxy.php?F=private/management.php'>Management*</a></br>
  *<i>restricted ressource</i><br/>
</center>
