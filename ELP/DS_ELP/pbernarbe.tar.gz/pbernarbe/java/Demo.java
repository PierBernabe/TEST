public class Demo {

    public static void main(String args[]) {

	A pbe1 = new A(); 
	B pbe2 = new B(); 
	A pbe3 = new B(); 
	C pbe4 = new B(); 
	
	pbe1.pbernarbe(); 
	pbe2.pbernarbe(); 
	pbe2.ebranrebp(); 
	pbe3.pbernarbe(); 
	pbe4.ebranrebp(); 

    }

}