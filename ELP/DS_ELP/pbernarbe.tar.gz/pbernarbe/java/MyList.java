import java.util.List; 
import java.util.ArrayList; 
import java.io.OutputStream; 

class MyList {

    List<Double> myList = new ArrayList<Double>(); 

    public static void pbernarbe(OutputStream aStream) {
	//print the content of myList to aStream with a for each loop
    }

    public static void ebranrebp(OutputStream aStream) {
	//print the content of myList to aStream with an iterator
    }

    public static void main(String args[]) {
	//call the different functions to print the content of myList
	//1) to the standard output
	//2) to the standard error
	//3) to a file called "pbe.dat"

    }

}
