public class A extends C{
	public void pbernarbe(){
		System.out.print("a");
	}
}