public class C {
	public void pbernarbe(){
		System.out.print("b");
	}

	public void ebranrebp() {
		System.out.print("c");
	}
}