public class B extends A{
	public void pbernarbe(){
		System.out.print("b");
	}
	public void ebranrebp(){
		System.out.print("c");
	}
}