int addition5(int x) {
  int res = 5; 
  res += x;
  return res; 
}

int main() {
  int a = 1; 
  int a5 = addition5(a); 
  return 0; 
}
