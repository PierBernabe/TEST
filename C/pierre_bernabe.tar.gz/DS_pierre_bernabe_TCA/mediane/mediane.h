#ifndef _NODE_H
#define _NODE_H

double mediane(int tab[], int size);


#endif
