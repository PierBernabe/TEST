ARBRE nouvelArbre(int val, ARBRE fg, ARBRE fd);
int hauteurArbre(ARBRE arbre);
void afficherArbre(ARBRE arbre, int decalage);
int arbreEquilibre (ARBRE arbre);

