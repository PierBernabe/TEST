/* 
constantes.h (source Michel Simatic)
*/ 

#define NBMEG 5 

#define BYTES (NBMEG * 1<<20) 
#define COLS 4096 
#define LIGNES (BYTES/COLS) 

